<?php

function Connection(){
$connect=mysqli_connect("localhost","root","","smallbasket");

	return $connect;

}

 ?>
