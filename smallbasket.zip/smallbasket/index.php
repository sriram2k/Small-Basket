<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Home</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto|Varela+Round">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="css/modalcss.css">

  </head>
  <body>
    <div class="section"> <br /><br /><br /><br /><br /></div>
    <div class="container my-5">
      <center>
      <div class="row">
        <div class="col-md-6 ">
          <div class="card">
            <div class="card-body">
              <a href="#myModal" style="color:#45aba6;font-size:30px;" class="trigger-btn " data-toggle="modal">Shop Registration</a>
            </div>
          </div>
          <br />
        </div>

        <div class="col-md-6 ">
          <div class="card">
            <div class="card-body">
              <a href="#myModal1" style="color:#45aba6;font-size:30px;" class="trigger-btn " data-toggle="modal">Login Now</a>
            </div>
          </div>

        </div>
      </div>
      <center>
    </div>

    <div id="myModal" class="modal fade">
    	<div class="modal-dialog modal-login">
    		<div class="modal-content">
    			<div class="modal-header">
    				<div class="avatar">
    					<center>
                <i style="font-size:50px;padding:3%;" class="fa fa-shopping-basket" aria-hidden="true"></i>
    				</center></div>
    				<h4 class="modal-title">Register your Shop</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
    			</div>
    			<div class="modal-body">
    				<form action="enter.php" method="post">

              <div class="form-group">
    						<input type="text" class="form-control" name="sname" placeholder="Shop Name" required="required">
    					</div>
              <div class="form-group">
    						<input type="text" class="form-control" name="smno" placeholder="Shop Mobile Number" required="required">
    					</div>
              <div class="form-group">
    						<input type="text" class="form-control" name="semail" placeholder="Shop Email id" >
    					</div>
    					<div class="form-group">
    						<input type="text" class="form-control" name="saddr" placeholder="Shop Address" required="required">
    					</div>
    					<div class="form-group">
    						<button type="submit" class="btn btn-primary btn-lg btn-block login-btn">Register</button>
    					</div>
    				</form>
    			</div>
    			<div class="modal-footer">
    				Welcome to our Community !!!
    			</div>
    		</div>
    	</div>
    </div>

    <div id="myModal1" class="modal fade">
    	<div class="modal-dialog modal-login">
    		<div class="modal-content">
    			<div class="modal-header">
    				<div class="avatar">
    					<center>
                <i style="font-size:50px;padding:2%;" class="fa fa-user-o" aria-hidden="true"></i>
    				</center></div>
    				<h4 class="modal-title">ShopKeeper Login</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
    			</div>
    			<div class="modal-body">
    				<form action="check.php" method="post">
    					<div class="form-group">
      						<input type="email" class="form-control" name="email" placeholder="Email ID" required="required">
    					</div>
    					<div class="form-group">
    						<input type="password" class="form-control" name="password" placeholder="Mobile Number" required="required">
    					</div>
    					<div class="form-group">
    						<button type="submit" class="btn btn-primary btn-lg btn-block login-btn">Login</button>
    					</div>
    				</form>
    			</div>
    			<div class="modal-footer">
    				Welcome to our Community !!!
    			</div>
    		</div>
    	</div>
    </div>

    <?php

    if(isset($_GET["smsg"])){
      $id=$_GET["smsg"];
      echo "<h1><script>alert('Your Shop ID is $id')</script></h1>";
    }
    if(isset($_GET['login'])){
      if($_GET['login'] == "success"){
        header("Location:home.php");
        exit();
      }
      if($_GET['login'] == "failed"){
        echo "<h1><script>alert('Check Login Details')</script></h1>";
      }

    }
     ?>

  </body>
</html>
